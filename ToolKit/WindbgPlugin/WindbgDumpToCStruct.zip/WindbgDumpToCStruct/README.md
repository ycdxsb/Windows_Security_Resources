# WindbgDumpToCStruct

Tool to parse dt dump from Windbg to a C header file. See example for details

<h2> Arguments </h2>

Command line args : python dt2header.py <input_file_name> <struct_name>

<h2> Example </h2>

Example : python dt2header.py peb64.txt _PEB64




<h1>GNU General Public License v3.0</h1>

Permissions of this strong copyleft license are conditioned on making available complete source code of licensed works and modifications, which include larger works using a licensed work, under the same license. Copyright and license notices must be preserved. Contributors provide an express grant of patent rights.
